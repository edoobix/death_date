window.onload = () => {
	var opacityDivs = document.querySelectorAll('#opac');
	var clientH = document.documentElement.clientHeight;

	window.addEventListener('resize',() => {
		clientH = document.documentElement.clientHeight;
	});

	var scrolled = window.pageYOffset + clientH;
	window.addEventListener('scroll',() => {
		scrolled = window.pageYOffset + clientH;
		showingDivs();
	});	

	showingDivs();
	function showingDivs(){
		for(let i = 0; i < opacityDivs.length; i++){
			let divHeight = (opacityDivs[i].getBoundingClientRect().top + parseInt(window.getComputedStyle(opacityDivs[i]).getPropertyValue("height"))/3) - clientH;//opacityDivs[i].getBoundingClientRect().top - (parseInt(window.getComputedStyle(opacityDivs[i]).getPropertyValue("height"))) ;
			if(divHeight <= 0){
				opacityDivs[i].classList.remove('hidden');
				opacityDivs[i].classList.add('visible');
			}
		}
	}

};