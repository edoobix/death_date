window.onload = () => {
	var question1 = document.querySelector('#q1');
	var question2 = document.querySelector('#q2');
	var question3 = document.querySelector('#q3');
	var question4 = document.querySelector('#q4');
	var question5 = document.querySelector('#q5');

	var loading = document.querySelector('#loading');

	var next1 = document.querySelectorAll('#next1');
	var next2 = document.querySelector('#next2');
	var next3 = document.querySelectorAll('#next3');
	var next4 = document.querySelectorAll('#next4');

	var months = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Окрябрь','Ноябрь','Декабрь'];
	var day = document.querySelector('#day');
	var month = document.querySelector('#month');
	var year = document.querySelector('#year');

	var messages = document.querySelector('#messages');

	var linein = document.querySelector('#line-in');
	var pers = document.querySelector('#pers');
	var inter;

	var date = document.querySelector('#date');

	var tom = new Date();
	var nextDayDate = ((tom.getDate() + 1) + '.' + (tom.getMonth() + 1) + '.' + tom.getFullYear());
	date.innerHTML = nextDayDate;



	for(let i = 1; i <= 31; i++){
		let option = document.createElement('option');
		option.innerHTML = i;
		day.appendChild(option);
	}
	for(let i = 1950; i <= 2021; i++){
		let option = document.createElement('option');
		option.innerHTML = i;
		year.appendChild(option);
	}
	for(let i = 0; i < months.length;i++){
		let option = document.createElement('option');
		option.innerHTML = months[i];
		month.appendChild(option);
	}	


	day.addEventListener('change', () => {
		if(day.value != 'День'){
			day.classList.remove('warn');
		}
	});

	month.addEventListener('change', () => {
		if(month.value != 'Месяц'){
			month.classList.remove('warn');
		}
	});

	year.addEventListener('change', () => {
		if(year.value != 'Год'){
			year.classList.remove('warn');
		}
	});


	next2.onclick = (e) => {
		if((day.value != 'День') && (month.value != 'Месяц') && (year.value != 'Год')){
			e.preventDefault();
			question2.classList.remove('show');
			question3.classList.add('show');
		} else {
			if(day.value == 'День'){
				day.classList.add('warn');
			}
			if(month.value == 'Месяц'){
				month.classList.add('warn');
			}
			if(year.value == 'Год'){
				year.classList.add('warn');
			}			
		}
	};

	for(let i = 0; i < next1.length; i++){
		next1[i].onclick = (e) => {
			e.preventDefault();
			question1.classList.remove('show');
			question2.classList.add('show');		
		};
	}

	for(let i = 0; i < next3.length; i++){
		next3[i].onclick = (e) => {
			e.preventDefault();
			question3.classList.remove('show');
			loading.classList.add('show');
			ageCalc();
			setTimeout(afterLoading,2000);		
		};
	}

	for(let i = 0; i < next4.length; i++){
		next4[i].onclick = (e) => {
			e.preventDefault();
			question4.classList.remove('show');
			record.classList.add('show');
			linein.classList.add("line-mic-in");
			inter = setInterval(progress,50);
			setTimeout(showLast,5100);
		};
	}

	function showLast(){
		record.classList.remove('show');
		question5.classList.add('show');
	}

	let i = 0;
	function progress(){		
		pers.innerHTML = i+' %';
		i++;
		if(i == 101){
			clearInterval(inter);
			i = 0;
		}
	}

	function ageCalc(){
		//let now = new Date();
		//let nowYear = now.getFullYear();
		//let nowMonth = now.getMonth();
		//let nowDay = now.getDay();
		let birthYear = parseInt(year.value);
		let birthMonth = month.options.selectedIndex;
		let birthDay = parseInt(day.value);

		let now = new Date();
		let today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
		let dr = new Date(birthYear, birthMonth, birthDay);
		let drnow = new Date(today.getFullYear(), dr.getMonth(), dr.getDate());
		let age = today.getFullYear() - dr.getFullYear();


		
		if(today < drnow){
			age = age - 1;
		}

		let message_text;

		if((age >= 18) || (age)){
			message_text = 'По вам скучает очень близкий человек, которого больше нет в мире живых.';
		}
		if((age > 35)){
			message_text = 'По вам скучает очень близкий человек, которого больше нет в мире живых. Возможно это дедушка или бабушка.';
		}
		if(age > 46){
			message_text = 'По вам скучает очень близкий человек, которого больше нет в мире живых. Возможно это кто-то из Ваших родителей.';
		}

		messages.innerHTML = message_text;				
	}

	function afterLoading(){
		loading.classList.remove('show');
		question4.classList.add('show');
	}	




	///////////////JSON//////////////


	var requestDiv = document.querySelector('#requestDiv');
	var requestLoading = document.querySelector('#requestLoading');




	var jsonBut = document.querySelector('#data');
	var parseBlock = document.querySelector('#request');
	var datas;

	jsonBut.onclick = (e) => {
		e.preventDefault();
		let request = new XMLHttpRequest();
    	request.open('GET', 'https://swapi.dev/api/people/1/');
    	request.responseType = 'json';
    	request.send();
    	requestLoading.classList.remove('hide');
   		request.onload = () => {
   			requestLoading.classList.add('hide');
   			requestDiv.classList.remove('hide');
   			datas = request.response;
   			writeParsed();
    	}

	};

	function writeParsed(){
		console.log(datas);
		for(key in datas){
			let spin = document.createElement('p');
			let row = '';
			if(Array.isArray(datas[key])){
				if(datas[key].length != 0){
					for(let i = 0; i< datas[key].length; i++){
						row += datas[key][i]+'<br>'
					}
				} else {
					row = 'empty';
				}
			} else {
				row = datas[key];
			}
			spin.innerHTML = key+': <br><span>'+row+'<br></span>';
			parseBlock.appendChild(spin);
			row = '';
		}
	}

};